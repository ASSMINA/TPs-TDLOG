class NoAmmunitionError(Exception):
    pass


class OutOfRangeError(Exception):
    pass


class DestroyedError(Exception):
    pass
